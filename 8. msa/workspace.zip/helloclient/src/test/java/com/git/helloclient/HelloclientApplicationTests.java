package com.git.helloclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
